package hello.itemservice.domain.item;

public interface SaveCheck {
}
